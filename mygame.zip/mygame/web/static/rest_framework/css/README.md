# Evennia API static files

Overrides for API files.
