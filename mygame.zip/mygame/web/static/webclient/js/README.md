You can replace the javascript files for Evennia's webclient page here.

You can find the original files in `evennia/web/static/webclient/js/`
