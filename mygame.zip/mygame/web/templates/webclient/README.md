Replace Evennia's webclient django template with your own here.

You can find the original files in `evennia/web/templates/webclient/`. Just copy
the original here and modify - after a reload the new template will be used.
