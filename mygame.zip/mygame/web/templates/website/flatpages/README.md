Flatpages require a default.html template, which can be overwritten by placing it in this folder.

You can find the original files in `evennia/web/website/templates/website/flatpages/`
